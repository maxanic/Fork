﻿namespace ForkCommon.Model.Payloads;

public abstract class AbstractPayload
{
}