﻿namespace ForkCommon.Model.Notifications;

public abstract class AbstractNotification
{
}