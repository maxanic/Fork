﻿namespace ForkCommon.Model.Entity.Enums;

public enum AutomationType
{
    Start,
    Stop,
    Restart
}