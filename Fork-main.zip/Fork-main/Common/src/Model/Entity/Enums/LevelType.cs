﻿namespace ForkCommon.Model.Entity.Enums;

public enum LevelType
{
    Default,
    Flat,
    Largebioms,
    Amplified,
    Buffet
}