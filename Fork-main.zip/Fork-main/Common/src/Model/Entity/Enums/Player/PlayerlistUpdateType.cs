﻿namespace ForkCommon.Model.Entity.Enums.Player;

public enum PlayerlistUpdateType
{
    Add,
    Update,
    Remove
}