﻿namespace ForkCommon.Model.Entity.Enums;

public enum VersionType
{
    Vanilla,
    VanillaSnapshot,
    Paper,
    Spigot,
    Waterfall,
    BungeeCord,
    Purpur
}
