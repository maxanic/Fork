﻿namespace ForkCommon.Model.Entity.Enums;

public enum EntityStatus
{
    Stopped,
    Starting,
    Started,
    Stopping,
    Crashed
}