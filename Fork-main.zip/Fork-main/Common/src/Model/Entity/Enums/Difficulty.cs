﻿namespace ForkCommon.Model.Entity.Enums;

public enum Difficulty
{
    Peaceful,
    Easy,
    Normal,
    Hard
}