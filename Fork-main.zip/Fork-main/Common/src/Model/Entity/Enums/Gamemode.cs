﻿namespace ForkCommon.Model.Entity.Enums;

public enum Gamemode
{
    Survival,
    Creative,
    Adventure,
    Spectator
}