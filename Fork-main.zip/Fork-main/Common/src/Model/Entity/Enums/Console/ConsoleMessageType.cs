﻿namespace ForkCommon.Model.Entity.Enums.Console;

public enum ConsoleMessageType
{
    Default,
    Error,
    Warning,
    Success,
    UserInput
}