﻿namespace ForkCommon.Model.Privileges.Application;

public interface IApplicationPrivilege : IPrivilege
{
}