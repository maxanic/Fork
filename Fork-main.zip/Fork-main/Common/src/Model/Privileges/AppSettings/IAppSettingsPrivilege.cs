﻿namespace ForkCommon.Model.Privileges.AppSettings;

public interface IAppSettingsPrivilege : IPrivilege
{
}