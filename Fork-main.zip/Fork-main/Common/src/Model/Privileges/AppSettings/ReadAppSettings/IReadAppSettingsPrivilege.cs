﻿namespace ForkCommon.Model.Privileges.AppSettings.ReadAppSettings;

public interface IReadAppSettingsPrivilege : IAppSettingsPrivilege
{
}