﻿namespace ForkCommon.Model.Privileges.AppSettings.WriteAppSettings;

public interface IWriteAppSettingsPrivilege : IAppSettingsPrivilege
{
}