﻿namespace ForkCommon.Model.Privileges.Entity.ReadEntity.ReadSettingsTab;

public interface IReadSettingsTabPrivilege : IReadEntityPrivilege
{
}