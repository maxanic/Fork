﻿namespace ForkCommon.Model.Privileges.Entity.ReadEntity;

public interface IReadEntityPrivilege : IEntityPrivilege
{
}