﻿namespace ForkCommon.Model.Privileges.Entity.ReadEntity.ReadConsoleTab;

public interface IReadConsoleTabPrivilege : IReadEntityPrivilege
{
}