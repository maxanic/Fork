﻿namespace ForkCommon.Model.Privileges.Entity.WriteEntity.WriteSettingsTab;

public interface IWriteSettingsTabPrivilege : IWriteEntityPrivilege
{
}