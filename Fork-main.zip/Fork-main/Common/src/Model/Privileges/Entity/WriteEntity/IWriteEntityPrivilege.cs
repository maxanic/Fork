﻿namespace ForkCommon.Model.Privileges.Entity.WriteEntity;

public interface IWriteEntityPrivilege : IEntityPrivilege
{
}