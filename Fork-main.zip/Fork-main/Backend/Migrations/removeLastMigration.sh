#!/bin/bash 

dotnet-ef migrations remove -- --host