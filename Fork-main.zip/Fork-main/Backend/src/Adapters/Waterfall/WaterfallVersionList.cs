namespace Fork.Adapters.Waterfall;

public class WaterfallVersionList
{
    public required string project_id;
    public required string project_name;
    public required string[] version_groups;
    public required string[] versions;
}
