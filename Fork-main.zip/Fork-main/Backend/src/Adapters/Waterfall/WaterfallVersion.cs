namespace Fork.Adapters.Waterfall;

public class WaterfallVersion
{
    public required int[] builds;
    public required string project_id;
    public required string project_name;
    public required string version;
}
