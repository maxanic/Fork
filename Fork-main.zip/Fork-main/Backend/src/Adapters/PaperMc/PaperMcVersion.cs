﻿namespace Fork.Adapters.PaperMc;

public class PaperMcVersion
{
    public required int[] builds;
    public required string project_id;
    public required string project_name;
    public required string version;
}