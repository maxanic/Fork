namespace Fork.Adapters.Purpur;

public class PurpurVersionList
{
    public required string project;
    // public required string metadata;
    public required string[] versions;
}
