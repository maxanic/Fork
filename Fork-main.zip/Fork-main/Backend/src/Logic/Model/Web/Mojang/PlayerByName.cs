﻿namespace Fork.Logic.Model.Web.Mojang;

public class PlayerByName
{
    public string? Id { get; set; }
    public string? Name { get; set; }
}