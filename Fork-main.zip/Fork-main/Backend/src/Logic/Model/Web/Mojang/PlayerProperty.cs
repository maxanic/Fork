﻿namespace Fork.Logic.Model.Web.Mojang;

public class PlayerProperty
{
    public string? Name { get; set; }
    public string? Value { get; set; }
}