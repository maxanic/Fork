﻿namespace ForkFrontend.Logic.Utility.Logging;

public class ForkLoggerOptions
{
}