﻿using Microsoft.AspNetCore.Components;

namespace ForkFrontend.Razor.Components.Entity.Tabs;

public abstract class EntityTab : ComponentBase
{
}