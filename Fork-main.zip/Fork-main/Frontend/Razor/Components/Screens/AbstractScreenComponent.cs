﻿using ForkFrontend.Razor.Components.Shared;

namespace ForkFrontend.Razor.Components.Screens;

public abstract class AbstractScreenComponent : AbstractForkComponent
{
}