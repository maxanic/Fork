﻿namespace ForkFrontend.Model.Enums;

public enum RadioType
{
    Default,
    ButtonRow
}