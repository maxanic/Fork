﻿namespace ForkFrontend.Model.Enums;

public enum ApplicationStatus
{
    Ready,
    RetrievingState,
    WaitingForWebsocket
}