﻿namespace ForkFrontend.Model.Enums;

public enum ToastLevel
{
    Success,
    Info,
    Warning,
    Error
}