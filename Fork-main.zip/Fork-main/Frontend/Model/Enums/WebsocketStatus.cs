﻿namespace ForkFrontend.Model.Enums;

public enum WebsocketStatus
{
    Disconnected,
    Connected
}